if ! test -e /data/adb/ssh/KEEP_ON_UNINSTALL ; then
    rm -rf /data/adb/ssh
fi
